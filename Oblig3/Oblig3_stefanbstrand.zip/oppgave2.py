# Funksjon - Tallgenerering

import random

def random_numbers():
    print(random.randrange(0, 100))


random_numbers()
random_numbers()
random_numbers()
random_numbers()
