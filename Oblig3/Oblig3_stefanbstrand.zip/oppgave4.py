# Funksjon - Volum

def calculate_volume(length, height, width):
    volume = float(length) * float(height) * float(width)
    return volume


print(f"The volume is: {calculate_volume(3, 3,3)}")
print(f"The volume is: {calculate_volume(4,5,8)}")
print(f"The volume is: {calculate_volume(3.5, 6, 7.4)}")
