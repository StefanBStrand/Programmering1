# Funksjon - printe liste


def print_list(snacks):
    for meal in snacks:
        print(meal)


favourite_meals = ["Cookies", "Protein Bars", "Chocolate Milk"]

print_list(favourite_meals)
