# While loops and for loops

i = 9
while i <= 102:
    print(i)
    i += 2

for j in range(9, 102, 2):  # three parameters: start, stop and increment values are passed in here.
    print(j)
