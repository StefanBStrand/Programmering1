a = 6
b = 3
c = 2

result = a + b * c
print(str(a) + " + " + str(b) + " * " + str(c) + " = " + str(result))

result = (a + b) * c
print("(" + str(a) + " + " + str(b) + ")" + " * " + str(c) + " = " + str(result))

result = a / b / c
print(str(a) + " / " + str(b) + " / " + str(c) + " = " + str(result))

result = a / (b / c)
print(str(a) + " / " + "(" + str(b) + " / " + str(c) + ")" + " = " + str(result))

#  I chose to do the same in this task, printing the calculations here too.
