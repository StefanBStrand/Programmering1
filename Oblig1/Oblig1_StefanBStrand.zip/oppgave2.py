first_name = "Stefan"
last_name = "Strand"
age = str(35)  # Using the str function to convert the number to a string,
# so it can be printed out in the result variable.

result = "Hei. Jeg heter " + first_name + " " + last_name + " og er " + age + " år gammel."
print(result)
