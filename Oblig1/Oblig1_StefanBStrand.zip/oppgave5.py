p1 = 5
p2 = 9
p3 = 2.5
p4 = 21
p5 = 0

total = p1 + p2 + p3 + p4 + p5
num_of_cookie_eaters = 5  # Variable to store/represent amount of people.

result = total / num_of_cookie_eaters
print(str(total) + " / " + " 5 " + " = " + str(int(result)))
#  Line 11: in order to print the answer as an integer,
#  the int function is used on the result variable.
